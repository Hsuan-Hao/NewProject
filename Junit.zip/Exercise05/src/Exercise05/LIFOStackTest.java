package Exercise05;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Perng
 *
 */
public class LIFOStackTest 
{
	private LIFOStack testStack;
	String testString = "for test";
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception 
	{
		testStack = new LIFOStack();
		testStack.Stack();
		testStack.push(testString);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void test() 
	{
		String popString = testStack.pop();
		assertEquals(popString, testString);
	}
	
	@Test
	public void testIsFull() 
	{
		assertTrue(testStack.isFull());
	}
	
	@Test
	public void testIsEmpty() 
	{
		testStack.pop();
		assertTrue(testStack.isEmpty());
	}

}
