/**
 * 
 */
package Exercise05;

import java.io.Serializable;

/**
 * The assignment is to make a new class called LIFOStack which implements a 
 * (Last In First Out) stack of strings and an interface to manipulate it.
 * 
 * @author Perng Hsuan-Hao
 */
public class LIFOStack implements Serializable
{
	private String[] stackArray; //The array used for the stack.
	private int positionOfTop; //the position of the top.
	
	public class StackFullException extends Exception 
	{
		public StackFullException() 
		{
			System.out.println("Stack Full Exception!");
		}
	}
	
	public class StackEmptyException extends Exception 
	{
		public StackEmptyException() 
		{
			System.out.println("Stack Empty Exception!");
		}
	}
	
	public class UnderFlowException extends Exception 
	{
		public UnderFlowException() 
		{
			System.out.println("Under Flow Exception!");
		}
	}
	
	public LIFOStack() 
	{
		//this.stackArray = new String[1];
		//this.positionOfTop = 0;
	}
	
	public LIFOStack(LIFOStack LS) 
	{
		this.stackArray = new String[LS.stackArray.length];
		System.arraycopy(LS.stackArray, 0, this.stackArray, 0, this.stackArray.length);
		this.positionOfTop = LS.positionOfTop;
	}
	
	/**
	 * Makes a new stack with an array of size 1. 
	 * The position of top should be 0 and saved should be false.
	 */
	public void Stack() 
	{
		this.stackArray = new String[1];
		this.positionOfTop = 0;
	}
	
	/**
	 * Makes a new stack with an array of size n. 
	 * The position of top should be 0 and saved should be false.
	 */
	public void Stack(int n) 
	{
		this.stackArray = new String[n];
		this.positionOfTop = 0;
	}
	
	/**
	 * Put the String s on top of the stack. 
	 * StackFullException when the stack has no more room for s.
	 */
	public void push(String s) 
	{
		try 
		{
			if (isFull())
			{
				throw new StackFullException();
			}
				
			else 
			{
				this.stackArray[this.positionOfTop] = s;
				this.positionOfTop++;
			}
		} 
		catch (StackFullException sfe) 
		{
			System.out.println("The stack has no more room for \"" + s + "\".");
		} 
		catch (NullPointerException npe) 
		{
			System.out.println("Null Pointer Exception!");
		}
	}
	
	/**
	 * Remove the String on top of the stack. 
	 * StackEmptyException when the stack is empty.
	 */
	public String pop() 
	{
		try 
		{
			if (isEmpty())
			{
				throw new StackEmptyException();
			}
				
			else 
			{
				String popTop =  this.stackArray[this.positionOfTop-1];
				this.stackArray[this.positionOfTop-1] = null;
				this.positionOfTop--;
				return popTop;
			}
		} 
		catch (StackEmptyException see) 
		{
			System.out.println("The stack is empty.");
			return "null";
		}
	}
	
	/**
	 * Add n spaces to the size of array in the stack.
	 * The argument n can be negative as well, in which case the stack size shrinks.
	 * If the stack size will become smaller than positionOfTop a UnderFlowException should be thrown.
	 */
	public void newSize(int n) 
	{
		try 
		{
			//If the new size is smaller than positionOfTop
			if((this.stackArray.length + n) < this.positionOfTop) 
			{
				throw new UnderFlowException();
			} 
			
			//If the new size is zero
			else if((this.stackArray.length + n) == 0) 
			{
				System.out.println("The stack size will be zero!");
			} 
			
			else 
			{
				//Copy the Stack
				String[] copyStack = new String[this.stackArray.length];
				System.arraycopy(this.stackArray, 0, copyStack, 0, this.stackArray.length);
				
				//Create a new size
				this.stackArray = new String[this.stackArray.length + n];
				
				//Re-put the stack back to the stackArray
				if(n < 0)
				{
					System.arraycopy(copyStack, 0, this.stackArray, 0, this.stackArray.length);
				}
					
				else
				{
					System.arraycopy(copyStack, 0, this.stackArray, 0, copyStack.length);
				}
			}
		}
		catch (UnderFlowException ufe) 
		{
			System.out.println("The stack size will become smaller than positionOfTop.");
		}
		catch (NullPointerException npe) 
		{
			System.out.println("Null Pointer Exception!");
		}
	}
	
	/**
	 * Returns True if positionOfTop is zero.
	 */
	public boolean isEmpty() 
	{
		if (this.positionOfTop == 0)
		{
			return true;
		}
			
		else
		{
			return false;
		}	
	}
	
	/**
	 * Returns True if positionOfTop is equal to the size of stackArray.
	 */
	public boolean isFull() 
	{
		if (this.positionOfTop == this.stackArray.length)
		{
			return true;
		}
			
		else
		{
			return false;
		}
	}
	
	/**
	 * Returns the amount of space left in stackArray.
	 */
	public int spaceLeft() 
	{
		return this.stackArray.length - this.positionOfTop;
	}
}
