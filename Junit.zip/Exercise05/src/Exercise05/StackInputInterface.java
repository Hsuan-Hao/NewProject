/**
 * 
 */
package Exercise05;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Scanner;

/**
 * In the main function we will have one reference variable to a LIFOStack and one boolean variable which will be called saved. 
 * You are to write code that reads from Standard input Like a commandline command, i.e. 
 * Waits for user input and executes the commands received.
 * 
 * @author Perng Hsuan-Hao
 */
public class StackInputInterface implements Serializable
{
	public static class StackOverwriteException extends Exception 
	{
		public StackOverwriteException() 
		{
			System.out.println("Stack Overwrite Exception!");
		}
	}
	
	public static class NoStackException extends Exception 
	{
		public NoStackException() 
		{
			System.out.println("Stack Overwrite Exception!");
		}
	}
	
	//To check the input string is numeric or not?
	public static boolean isNumeric(String input) 
	{
		try 
		{
			Integer.parseInt(input);
			return true;
		}
		catch (NumberFormatException e) 
		{
			//input is not numeric
			return false;
		}
	}
	
	/**
	 * Saves a stack LS to out (will be a file in our case).
	 * Should be saved as an Object.
	 */
	public static void Save(LIFOStack LS, OutputStream out) 
	{
		try 
		{
			ObjectOutputStream oout = new ObjectOutputStream(out);
			oout.writeObject(LS);
			oout.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Loads a Stack from the given input stream (will be a file in our case).
	 * Should be loaded as an Object.
	 */
	public static LIFOStack Load(InputStream In) 
	{
		LIFOStack loadStack = new LIFOStack();
		try 
		{
			ObjectInputStream ois = new ObjectInputStream(In);   
			loadStack = (LIFOStack) ois.readObject();
			ois.close();
		} 
		catch(IOException ioe) 
		{
			System.out.println("I/O Exception!");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("Class Not Found Exception!");
		}
		
		return loadStack;
	}
	
	/**
	 * Fills the stack with Strings from the given input stream (will be a file in our case).
	 * Think about the cases when the stack cannot be filled or needs to change to be filled.
	 */
	public static void FillStack(LIFOStack LS, InputStream In) 
	{
		LIFOStack InputFileStack = Load(In);
		String temp = "";
		String split_string = "----Here is the split point----";
		int count = 0;
		int left = LS.spaceLeft();
		
		while(!InputFileStack.isEmpty()) 
		{
			temp = InputFileStack.pop() + split_string + temp;
			count++;
		}
		
		if(LS.isFull()) 
		{	
			// check the stack is full or not.
			System.out.println("The stack is full needs adding at least " + count + " space(s).");
		} 
		
		else 
		{	
			// check the rest space of the stack is enough or not.
			if(left < count) 
			{
				System.out.println("The stack needs adding at least " + (count - left) + " space(s).");
			} 
			
			else 
			{		
				// fills the stack.
				String[] inputresults = temp.split(split_string);
				for(int i=0; i<inputresults.length; i++)
				{
					LS.push(inputresults[i]);
				}
			}
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		LIFOStack LIFO_S = new LIFOStack();
		boolean occupied = false;
		boolean saved = false;
		
		System.out.println("LIFO Stack and Java IO");
		String command = "";
		while(!command.equals("13") && !command.equals("Quit") && !command.equals("quit"))
		{
			System.out.println("====================================");
			System.out.println("1. new");
			System.out.println("2. delete");
			System.out.println("3. push");
			System.out.println("4. pop");
			System.out.println("5. load");
			System.out.println("6. save");
			System.out.println("7. changeSize");
			System.out.println("8. isEmpty");
			System.out.println("9. isFull");
			System.out.println("10. spaceLeft");
			System.out.println("11. printStack");
			System.out.println("12. concat");
			System.out.println("13. Quit");
			System.out.println("====================================");
			System.out.print("Input a command's you want: ");
			command = scanner.nextLine();
			
			//Makes a new stack
			if(command.equals("1") || command.equals("new"))
			{
				try
				{
					//If the reference variable is already occupied throw a StackOverwriteException.
					if (occupied == true) 
					{
						throw new StackOverwriteException();
					}
					
					System.out.print("What size do you want to create: ");
					int size = -1;
					
					while(size <= 0)
					{
						String size_string = "";
						size_string = scanner.nextLine(); 
						
						while(!isNumeric(size_string)) //if user input is not numeric
						{
							System.out.print("Your input is not numeric, please input again: ");
							size_string = scanner.nextLine(); 
						}
						
						size = Integer.parseInt(size_string);
						
						if (size > 1) 
						{
							// create a stack with size n
							LIFO_S.Stack(size);
						} 
						
						else if(size == 1)
						{
							// create a stack with size 1
							LIFO_S.Stack();
						}
						
						else //if user input is smaller than 1
						{
							System.out.print("You can't smaller than 1, please input again: ");
						}
					}
					
					System.out.println("Your stack has been created!");
					occupied = true;
					saved = false;
				}
				catch(StackOverwriteException soe) 
				{
					System.out.println("The variable is already occupied!");
				}
			}
			
			//Deletes the stack currently being referenced.
			else if(command.equals("2") || command.equals("delete"))
			{
				//System.out.println("2. delete");
				
				try 
				{
					//If no stack is referenced throw NoStackException.
					if(occupied == false) 
					{
						throw new NoStackException();
					} 
					
					//If the reference variable is occupied, but saved is false check if the user really wants to delete the stack.
					else if(occupied == true && saved == false) 
					{
						System.out.print("You haven't saved your stack. Do you really want to delete? (y/n): ");
						String d = scanner.nextLine();
						
						while(!d.equals("y") && !d.equals("n")) 
						{
							System.out.print("Wrong input, please type 'y' or 'n': ");
							d = scanner.nextLine();
						}
						
						if(d.equals("y"))
						{
							LIFO_S = new LIFOStack();
							occupied = false;
							saved = false;
							System.out.println("Your stack has been deleted!");
						}
					}
					
					else
					{
						LIFO_S = new LIFOStack();
						occupied = false;
						saved = false;
						System.out.println("Your stack has been deleted!");
					}
				} 
				catch(NoStackException nse) 
				{
					System.out.println("There is no stack being referenced.");
				}	
			}
			
			//Push string
			else if(command.equals("3") || command.equals("push"))
			{
				//System.out.println("3. push");
				String Some = "";
				System.out.print("What do you want to push, 'String' or 'File': ");
				Some = scanner.nextLine();
				
				while(!Some.equals("String") && !Some.equals("File")) 
				{
					System.out.print("Wrong input, please type 'String' or 'File': ");
					Some = scanner.nextLine();
				}
				
				if (Some.equals("String"))
				{
					// push "Some String"
					String SomeString = "";
					
					System.out.print("Input a string you want to push: ");
					SomeString = scanner.nextLine();
					
					LIFO_S.push(SomeString);
					saved = false;
					System.out.println("Your input has been pushed!");
				} 
				
				else 
				{
					// push Some_File
					String SomeFile = "";
					
					System.out.print("Input a file you want to push: ");
					SomeFile = scanner.nextLine();
					
					try 
					{
						InputStream In = new FileInputStream(SomeFile);
						FillStack(LIFO_S, In);
						saved = false;
						System.out.println("Your input has been pushed!");
					} 
					catch (FileNotFoundException fne) 
					{
						System.out.println("File Not Found Exception!");
					}
				}
			}
			
			//Pops the top of the stack and prints to standard out.
			else if(command.equals("4") || command.equals("pop"))
			{
				//System.out.println("4. pop");
				System.out.println("pop: " + LIFO_S.pop());
				saved = false;
			}
			
			//Load a stack from a file.
			else if(command.equals("5") || command.equals("load"))
			{
				//System.out.println("5. load");
				
				try 
				{
					//If the reference variable is already occupied throw a StackOverwriteException.
					if(occupied == true) 
					{
						throw new StackOverwriteException();
					} 
					
					else 
					{
						String SomeFile = "";
						
						System.out.print("Input a file you want to load: ");
						SomeFile = scanner.nextLine();
						
						try 
						{
							InputStream in = new FileInputStream(SomeFile);
							LIFO_S = Load(in);
							System.out.println("Your stack has been loaded!");
							in.close();
						}
						catch (FileNotFoundException fne) 
						{
							System.out.println("File Not Found Exception!");
						}
						catch(IOException ioe) 
						{
							System.out.println("I/O Exception!");
						} 
					}
					
					saved = false;
					occupied = true;
				} 
				catch (StackOverwriteException soe) 
				{
					System.out.println("The variable is already occupied.");
				}
			}
			
			//Save a stack to a file set the bollean saved to true.
			else if(command.equals("6") || command.equals("save"))
			{
				//System.out.println("6. save");
				
				String SomeFile = "";
				
				System.out.print("Assign a file name: ");
				SomeFile = scanner.nextLine();
				
				OutputStream os;
				try 
				{
					os = new FileOutputStream(SomeFile);
					Save(LIFO_S, os);
					os.close();
				} 
				catch (FileNotFoundException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch(IOException ioe) 
				{
					System.out.println("I/O Exception!");
				} 
				
				saved = true;
				System.out.println("Your stack has been saved into '" + SomeFile + "' file!");
			}
			
			//Change size of stack by n (can be a negative value).
			else if(command.equals("7") || command.equals("changeSize"))
			{
				//System.out.println("7. changeSize");
				System.out.print("Input a size you want to change: ");
				int size = 0;
				String size_string = "";
				size_string = scanner.nextLine(); 
				
				while(!isNumeric(size_string)) //if user input is not numeric
				{
					System.out.print("Your input is not numeric, please input again: ");
					size_string = scanner.nextLine(); 
				}
				
				size = Integer.parseInt(size_string);
				
				LIFO_S.newSize(size);
				saved = false;
			}
			
			//Outputs whether the stack is empty or not.
			else if(command.equals("8") || command.equals("isEmpty"))
			{
				//System.out.println("8. isEmpty");
				
				if (occupied == false)
				{
					System.out.println("You have not created a stack!");
				}
					
				else
				{
					System.out.println(LIFO_S.isEmpty());
				}
			}
			
			//Outputs whether the stack is full or not.
			else if(command.equals("9") || command.equals("isFull"))
			{
				//System.out.println("9. isFull");
				
				if (occupied == false)
				{
					System.out.println("You have not created a stack!");
				}
					
				else
				{
					System.out.println(LIFO_S.isFull());
				}
			}
			
			//Outputs the space left in the stack.
			else if(command.equals("10") || command.equals("spaceLeft"))
			{
				//System.out.println("10. spaceLeft");
				
				if (occupied == false)
				{
					System.out.println("You have not created a stack!");
				}
				
				else if(LIFO_S.spaceLeft() == 0)
				{
					System.out.println("Your stack is full.");
				}
				
				else
				{
					System.out.println("You still have " + LIFO_S.spaceLeft() + " left.");
				}
			}
			
			//Print the stack to standard out.
			else if(command.equals("11") || command.equals("printStack"))
			{
				//System.out.println("11. printStack");
				
				if (occupied == false)
				{
					System.out.println("You have not created a stack!");
				}
				
				else
				{
					System.out.println("Print your stack:");
					//make a second temporary stack.
					LIFOStack Print_LIFO = new LIFOStack(LIFO_S);
					while(!Print_LIFO.isEmpty())
					{
						System.out.println(Print_LIFO.pop());
					}
				}
			}
			
			//Takes the two top strings of the stack, removes them, concatenates them and puts the result on top.
			else if(command.equals("12") || command.equals("concat"))
			{
				//System.out.println("12. concat");
				
				if (occupied == false)
				{
					System.out.println("You have not created a stack!");
				}
				
				else if (LIFO_S.isEmpty())
				{
					System.out.println("The stack is empty.");
				}
				
				else
				{
					String s1 = LIFO_S.pop();
					
					if(LIFO_S.isEmpty()) //If there is only one element in the stack.
					{
						LIFO_S.push(s1);
					}
					else 
					{
						String s2 = LIFO_S.pop();
						LIFO_S.push(s1 + " " + s2);
					}
				}	
			}
			
			//Exits the program.
			else if(command.equals("13") || command.equals("Quit") || command.equals("quit"))
			{
				//System.out.println("13. Quit");
				
				//If the stack isn't saved, ask the user if they would like to quit anyway.
				if(occupied == true && saved == false) 
				{
					System.out.print("You haven't saved stack, Do you still want to quit? (y/n): ");
					String d = scanner.nextLine();
					
					while(!d.equals("y") && !d.equals("n")) 
					{
						System.out.print("Wrong input, please type 'y' or 'n': ");
						d = scanner.nextLine();
					}
					
					if (d.equals("n"))
					{
						command = "";
					}
				}
			}
			
			else
			{
				System.out.println("No exist command '" + command + "'.");
			}
			
			try 
			{
			    //try to do wait() like C
				Thread.sleep(1000);
				
				//Try to do System("cls") like C
				for(int i=0; i<25; i++)
			    {
			    	System.out.println("");
			    }
			} 
			catch(InterruptedException ie) 
			{
				System.out.println(ie);
			}
		}
		
		System.out.println("Thanks for using!");
		scanner.close();
	}
}
